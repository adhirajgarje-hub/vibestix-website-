/* VibeStix - final site JS
   Replace placeholders:
     EMAILJS_SERVICE -> your EmailJS service id
     EMAILJS_TEMPLATE -> your EmailJS template id
     EMAILJS_PUBLIC -> your EmailJS public key
     UPI_ID -> your UPI ID (optional)
*/

// ---------- CONFIG ----------
const ADMIN_EMAIL = atob("YWRtaW5AdmliZXN0aXguY29t"); // admin@vibestix.com (hidden)
const ADMIN_PASS  = atob("dmliZXN0aXgxMjM=");         // vibestix123 (hidden)

const EMAILJS_SERVICE = "EMAILJS_SERVICE_ID";     // replace
const EMAILJS_TEMPLATE = "EMAILJS_TEMPLATE_ID";  // replace
const EMAILJS_PUBLIC  = "EMAILJS_PUBLIC_KEY";    // replace
const ADMIN_RECEIVER  = "aakdigital9960@gmail.com"; // where signup/order emails go

const UPI_ID = "YOUR_UPI_ID"; // optional

const STORAGE_KEY = "vibestix_products_v2";

// ---------- DEFAULT PRODUCTS ----------
const DEFAULT_PRODUCTS = [
  { id: 1, name: "Vibe Aesthetic Pack", price: 199, image: "https://i.ibb.co/9Z9dQ7M.png", desc: "Set of 10 unique glossy stickers" },
  { id: 2, name: "Retro Laptop Stickers", price: 249, image: "https://i.ibb.co/9Z9dQ7M.png", desc: "Customizable with your name or text" },
  { id: 3, name: "Minimalist Black Frame (4x6)", price: 499, image: "https://i.ibb.co/t2b7cdt/photo-frame.jpg", desc: "Elegant matte finish" },
  { id: 4, name: "Floral Wooden Frame", price: 699, image: "https://i.ibb.co/t2b7cdt/photo-frame.jpg", desc: "Perfect for gifts" }
];

// ---------- UTIL ----------
const qs = s => document.querySelector(s);
const qsa = s => Array.from(document.querySelectorAll(s));
const toast = (msg) => { const t = qs('#toast'); t.textContent = msg; t.style.display = 'block'; setTimeout(()=> t.style.display='none', 2600); };

// ---------- STATE ----------
let products = loadProducts();
let currentCustomer = null;
let checkoutItem = null;
let checkoutQty = 1;

// ---------- EmailJS init ----------
if(window.emailjs && EMAILJS_PUBLIC !== "EMAILJS_PUBLIC_KEY"){
  emailjs.init(EMAILJS_PUBLIC);
}

// ---------- STORAGE ----------
function loadProducts(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(!raw) { localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_PRODUCTS)); return DEFAULT_PRODUCTS.slice(); }
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : DEFAULT_PRODUCTS.slice();
  }catch(e){ return DEFAULT_PRODUCTS.slice(); }
}
function saveProducts(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(products)); }

// ---------- RENDER ----------
const productGrid = qs('#productGrid');
const frameGrid = qs('#frameGrid');

function renderProducts(){
  productGrid.innerHTML = ""; frameGrid.innerHTML = "";
  products.forEach(p=>{
    const card = document.createElement('div'); card.className = 'product-card'; card.dataset.id = p.id;
    card.innerHTML = `
      <img src="${p.image}" alt="${escapeHtml(p.name)}" />
      <h4>${escapeHtml(p.name)}</h4>
      <p class="muted">${escapeHtml(p.desc||'')}</p>
      <div class="price">₹${Number(p.price)}</div>
      <div class="btns">
        <button class="view-btn btn-secondary" data-id="${p.id}">View</button>
        <button class="buy-btn btn-primary" data-id="${p.id}">Buy</button>
        <button class="edit-btn btn-outline hidden" data-id="${p.id}">Edit</button>
      </div>`;
    productGrid.appendChild(card);
    frameGrid.appendChild(card.cloneNode(true));
  });

  qsa('.buy-btn').forEach(b=> b.addEventListener('click', e => {
    const id = Number(e.currentTarget.dataset.id); openCheckout(id);
  }));
  qsa('.view-btn').forEach(b=> b.addEventListener('click', e => {
    const id = Number(e.currentTarget.dataset.id); const p = products.find(x=>x.id===id);
    alert(`${p.name}\n\n${p.desc}\n\nPrice: ₹${p.price}`);
  }));
}
function escapeHtml(s){ return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
renderProducts();

// ---------- CUSTOMER SIGNUP ----------
const custModal = qs('#customerSignupModal');
window.addEventListener('load', ()=>{
  const saved = sessionStorage.getItem('vibestix_customer');
  if(saved) currentCustomer = JSON.parse(saved);
  else showModal('customerSignupModal');
});

qs('#custSignupSubmit').addEventListener('click', ()=>{
  const name = qs('#cust_name').value.trim();
  const email = qs('#cust_email').value.trim();
  const phone = qs('#cust_phone').value.trim();
  const address = qs('#cust_address').value.trim();
  if(!name||!email||!phone||!address){ alert('Please fill all fields'); return; }
  currentCustomer = { name,email,phone,address };
  sessionStorage.setItem('vibestix_customer', JSON.stringify(currentCustomer));

  // Send via EmailJS if configured
  if(window.emailjs && EMAILJS_SERVICE !== "EMAILJS_SERVICE_ID"){
    const params = {
      to_email: ADMIN_RECEIVER,
      customer_name: name,
      customer_email: email,
      customer_phone: phone,
      customer_address: address
    };
    emailjs.send(EMAILJS_SERVICE, EMAILJS_TEMPLATE, params)
      .then(()=>{ toast('Signup info sent to admin'); hideModal('customerSignupModal'); })
      .catch(err=>{ console.error('EmailJS error', err); toast('Email send failed — opening mail fallback'); // fallback
        const subject = encodeURIComponent(`VibeStix - Signup: ${name}`);
        const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\nPhone: ${phone}\nAddress: ${address}`);
        window.open(`mailto:${ADMIN_RECEIVER}?subject=${subject}&body=${body}`);
        hideModal('customerSignupModal');
      });
  } else {
    // fallback: prepare mailto so user can send
    const subject = encodeURIComponent(`VibeStix - Signup: ${name}`);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\nPhone: ${phone}\nAddress: ${address}`);
    window.open(`mailto:${ADMIN_RECEIVER}?subject=${subject}&body=${body}`);
    toast('Signup prepared; open mail to send'); hideModal('customerSignupModal');
  }
});

// ---------- CHECKOUT ----------
const checkoutModal = qs('#checkoutModal');
const co_img = qs('#co_item_img'), co_name = qs('#co_item_name'), co_desc = qs('#co_item_desc');
const co_unit_price = qs('#co_unit_price'), co_subtotal = qs('#co_subtotal'), co_shipping = qs('#co_shipping'), co_total = qs('#co_total');
const qtyMinus = qs('#qtyMinus'), qtyPlus = qs('#qtyPlus'), qtyValue = qs('#qtyValue');
const co_payment_method = qs('#co_payment_method'), co_pay_btn = qs('#co_pay_btn'), co_cancel = qs('#co_cancel');

function openCheckout(productId){
  const p = products.find(x=>x.id===productId);
  if(!p) return alert('Product not found');
  checkoutItem = p; checkoutQty = 1;
  co_img.src = p.image; co_name.textContent = p.name; co_desc.textContent = p.desc||'';
  co_unit_price.textContent = `₹${p.price}`; qtyValue.textContent = checkoutQty;
  co_subtotal.textContent = `₹${p.price*checkoutQty}`; co_shipping.textContent = `₹30`;
  co_total.textContent = `₹${p.price*checkoutQty + 30}`;
  showModal('checkoutModal');
}
qtyMinus.addEventListener('click', ()=>{ if(checkoutQty>1) checkoutQty--; updateCheckout(); });
qtyPlus.addEventListener('click', ()=>{ checkoutQty++; updateCheckout(); });
function updateCheckout(){ const unit = Number(checkoutItem.price); const subtotal = unit*checkoutQty; co_subtotal.textContent = `₹${subtotal}`; co_total.textContent = `₹${subtotal+30}`; qtyValue.textContent = checkoutQty; }
co_cancel.addEventListener('click', ()=> hideModal('checkoutModal'));

// Pay Now
co_pay_btn.addEventListener('click', ()=>{
  if(!currentCustomer){ alert('Please sign up first.'); return; }
  const method = co_payment_method.value;
  const totalAmount = Number(checkoutItem.price)*checkoutQty + 30;
  const prodText = `${checkoutItem.name} (₹${checkoutItem.price}) x ${checkoutQty}`;

  if(method === 'online'){
    qsa('.app-btn').forEach(btn=>{
      const upi = btn.dataset.upi.replace('AMOUNT', encodeURIComponent(totalAmount)).replace('YOUR_UPI_ID', encodeURIComponent(UPI_ID));
      btn.dataset.real = upi;
    });
    showModal('paymentAppsModal'); return;
  }

  // COD fallback: mailto to admin
  const subject = encodeURIComponent(`VibeStix Order - COD - ${currentCustomer.name}`);
  const body = encodeURIComponent(`Order:\n${prodText}\nPayment: COD\n\nCustomer:\nName: ${currentCustomer.name}\nEmail: ${currentCustomer.email}\nPhone: ${currentCustomer.phone}\nAddress: ${currentCustomer.address}`);
  window.location.href = `mailto:${ADMIN_RECEIVER}?subject=${subject}&body=${body}`;
  toast('COD order prepared — open mail app to send'); hideModal('checkoutModal');
});

// Payment app buttons
qsa('.app-btn').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    const upiLink = btn.dataset.real || btn.dataset.upi;
    window.location.href = upiLink;
    // fallback: email admin
    setTimeout(()=>{
      const subject = encodeURIComponent(`VibeStix Order - Online - ${currentCustomer.name}`);
      const body = encodeURIComponent(`Order: ${checkoutItem.name} x ${checkoutQty}\nAmount: ₹${Number(checkoutItem.price)*checkoutQty + 30}\nCustomer: ${currentCustomer.name}, ${currentCustomer.email}, ${currentCustomer.phone}, ${currentCustomer.address}`);
      window.location.href = `mailto:${ADMIN_RECEIVER}?subject=${subject}&body=${body}`;
      hideModal('paymentAppsModal'); hideModal('checkoutModal'); toast('Opened payment app (or mail fallback).');
    },700);
  });
});

// ---------- ADMIN ----------
const adminOpen = qs('#adminOpen'), adminModal = qs('#adminModal'), adminEditModal = qs('#adminEditModal');

adminOpen.addEventListener('click', ()=> showModal('adminModal'));
qs('#adminLoginBtn').addEventListener('click', ()=>{
  const email = qs('#admin_email').value.trim();
  const pass = qs('#admin_password').value.trim();
  if(email === ADMIN_EMAIL && pass === ADMIN_PASS){
    hideModal('adminModal'); toast('Admin mode enabled');
    // reveal edit buttons
    qsa('.edit-btn').forEach(b=> b.classList.remove('hidden'));
    qsa('.edit-btn').forEach(b=> b.addEventListener('click', (e)=> openEditProduct(Number(e.currentTarget.dataset.id))));
    // add a quick add via edit modal
    openAddProductButton();
  } else {
    toast('Invalid admin credentials');
  }
});

// admin save / delete
qs('#adminSaveBtn').addEventListener('click', ()=>{
  const id = Number(qs('#edit_id').value);
  const name = qs('#edit_name').value.trim();
  const price = Number(qs('#edit_price').value);
  const image = qs('#edit_image').value.trim();
  const desc = qs('#edit_desc').value.trim();
  if(!name || !price || !image){ alert('Please fill name, price and image'); return; }
  if(id){ // update
    const idx = products.findIndex(p=>p.id===id);
    if(idx>-1){ products[idx] = { id, name, price, image, desc }; saveProducts(); renderProducts(); hideModal('adminEditModal'); toast('Product updated'); }
  } else { // add
    const nid = Date.now();
    products.push({ id: nid, name, price, image, desc }); saveProducts(); renderProducts(); hideModal('adminEditModal'); toast('Product added');
  }
});

qs('#adminDeleteBtn').addEventListener('click', ()=>{
  const id = Number(qs('#edit_id').value);
  if(!id){ alert('No product selected'); return; }
  if(confirm('Remove this product?')){ products = products.filter(p=>p.id!==id); saveProducts(); renderProducts(); hideModal('adminEditModal'); toast('Product removed'); }
});

function openEditProduct(id){
  const p = products.find(x=>x.id===id); if(!p) return;
  qs('#adminEditTitle').textContent = 'Edit Product';
  qs('#edit_id').value = p.id;
  qs('#edit_name').value = p.name;
  qs('#edit_price').value = p.price;
  qs('#edit_image').value = p.image;
  qs('#edit_desc').value = p.desc || '';
  showModal('adminEditModal');
}
function openAddProductButton(){ qs('#adminEditTitle').textContent = 'Add New Product'; qs('#edit_id').value=''; qs('#edit_name').value=''; qs('#edit_price').value=''; qs('#edit_image').value=''; qs('#edit_desc').value=''; showModal('adminEditModal'); }

// ---------- MODAL HELPERS ----------
function showModal(id){ const m = qs('#'+id); if(m) m.classList.add('show'); }
function hideModal(id){ const m = qs('#'+id); if(m) m.classList.remove('show'); }
qsa('.modal-close').forEach(btn => btn.addEventListener('click', ()=>{
  const target = btn.getAttribute('data-close'); if(target) hideModal(target); else btn.closest('.modal').classList.remove('show');
}));
window.addEventListener('click', (e)=>{ if(e.target.classList && e.target.classList.contains('modal')) e.target.classList.remove('show'); });

// ---------- INIT ----------
saveProducts();